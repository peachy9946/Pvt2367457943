$Password = "ms_by_rgadguard"
$Interval = 30
$DestinationFolder = "G:\ESD2\Windows 10 Insider Preview 10041.0" # Change this to your desired hardcoded path

while ($true) {
    Get-ChildItem -Path . -Filter "*.7z" -File | ForEach-Object {

        $archive = $_.FullName
        $extractPath = $_.DirectoryName

        try {
            Write-Host "Extracting: $archive"

            # Extract using 7z
            & 7z.exe x "$archive" "-p$Password" "-o$extractPath" -y

            if ($LASTEXITCODE -eq 0) {
                Write-Host "Extraction successful: $archive"

                # Delete all .HASH files inside extracted content
                Get-ChildItem -Path $extractPath -Recurse -Filter "*.HASH" -File -ErrorAction SilentlyContinue |
                    ForEach-Object {
                        Write-Host "Deleting HASH file: $($_.FullName)"
                        Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
                    }

                # Ensure destination folder exists
                if (-not (Test-Path $DestinationFolder)) {
                    New-Item -ItemType Directory -Path $DestinationFolder -Force | Out-Null
                }

                # Move extracted ESD files
                Get-ChildItem -Path $extractPath -Filter "*.esd" -File -ErrorAction SilentlyContinue |
                    ForEach-Object {
                        Write-Host "Moving ESD file: $($_.Name) to destination folder"
                        Move-Item -Path $_.FullName -Destination $DestinationFolder -Force -ErrorAction SilentlyContinue
                    }

                # Delete the archive after successful extraction
                Write-Host "Deleting archive: $archive"
                Remove-Item $archive -Force -ErrorAction SilentlyContinue
            }
            else {
                Write-Host "Extraction failed for: $archive"
            }
        }
        catch {
            Write-Host "Error processing $archive : $_"
        }
    }

    Start-Sleep -Seconds $Interval
}