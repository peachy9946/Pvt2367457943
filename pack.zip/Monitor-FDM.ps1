# Configuration
$DriveLetter = "D"
$MinSpaceGB = 10
$MaxSpaceGB = 30
$FdmPath = "C:\Program Files\Softdeluxe\Free Download Manager\fdm.exe"
$FdmProcessName = "fdm"
$CheckIntervalSeconds = 60

Write-Output "Starting FDM Monitor. Checking every $CheckIntervalSeconds seconds..."

while ($true) {
    # Get drive information
    $Drive = Get-PSDrive -Name $DriveLetter -PSProvider FileSystem -ErrorAction SilentlyContinue

    if ($Drive) {
        # Calculate free space in GB
        $FreeSpaceGB = [math]::Round($Drive.Free / 1GB, 2)
        Write-Output "[$((Get-Date).ToString())] Current free space on drive $($DriveLetter): is $FreeSpaceGB GB"

        if ($FreeSpaceGB -lt $MinSpaceGB) {
            Write-Output "[$((Get-Date).ToString())] Free space is below threshold ($MinSpaceGB GB). Stopping FDM..."
            $Process = Get-Process -Name $FdmProcessName -ErrorAction SilentlyContinue
            if ($Process) {
                Stop-Process -Name $FdmProcessName -Force
                Write-Output "[$((Get-Date).ToString())] FDM process killed."
            } else {
                Write-Output "[$((Get-Date).ToString())] FDM is not currently running."
            }
        }
        elseif ($FreeSpaceGB -gt $MaxSpaceGB) {
            Write-Output "[$((Get-Date).ToString())] Free space is above threshold ($MaxSpaceGB GB). Checking if FDM is running..."
            $Process = Get-Process -Name $FdmProcessName -ErrorAction SilentlyContinue
            if (-not $Process) {
                if (Test-Path $FdmPath) {
                    Write-Output "[$((Get-Date).ToString())] Starting FDM..."
                    Start-Process -FilePath $FdmPath
                    Write-Output "[$((Get-Date).ToString())] FDM started."
                } else {
                    Write-Warning "[$((Get-Date).ToString())] FDM executable not found at: $FdmPath"
                }
            } else {
                Write-Output "[$((Get-Date).ToString())] FDM is already running."
            }
        }
        else {
            Write-Output "[$((Get-Date).ToString())] Free space is between $MinSpaceGB GB and $MaxSpaceGB GB. No action required."
        }
    } else {
        Write-Warning "[$((Get-Date).ToString())] Drive $($DriveLetter): not found."
    }


    Start-Sleep -Seconds $CheckIntervalSeconds
}
