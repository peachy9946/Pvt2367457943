[CmdletBinding()]
param (
    [switch]$MissingUpload
)

Set-Location G:\ESD2
$basePath = (Get-Location).Path
if (-not $basePath.EndsWith('\')) {
    $basePath += '\'
}

# Configuration
$ItemIdentifier = "Windows-10-Insider-Preview-9841.0-ESD-Files"
$MaxConcurrentJobs = 6
$LogFile = if ($PSScriptRoot) { Join-Path $PSScriptRoot "upload_log.txt" } else { Join-Path $PWD "upload_log.txt" }

$uploadedFiles = @()
if ($MissingUpload) {
    Write-Host "Fetching list of already uploaded files from IA XML..."
    try {
        $xmlUrl = "https://archive.org/download/$ItemIdentifier/$($ItemIdentifier)_files.xml"
        $xmlData = Invoke-RestMethod -Uri $xmlUrl -ErrorAction Stop
        if ($null -ne $xmlData.files.file) {
            $uploadedFiles = @($xmlData.files.file | Select-Object -ExpandProperty name)
        } else {
            throw "XML parsed but no files found."
        }
    } catch {
        throw "Failed to fetch or parse file list: $_"
    }
}

$activeJobs = @{} # Dictionary to map File FullName to Process object

Write-Host "Starting continuous upload monitor..."

while ($true) {
    # 1. Clean up finished jobs
    $finishedFiles = @()
    foreach ($key in $activeJobs.Keys) {
        $process = $activeJobs[$key]
        if ($process.HasExited) {
            $finishedFiles += $key
            
            # Check if upload failed. We know it failed if the process exited with a non-zero code.
            if ($process.ExitCode -ne 0) {
                Write-Host "Upload failed for $key with ExitCode $($process.ExitCode). Will retry in future scans." -ForegroundColor Red
                "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - FAILED: $key" | Out-File -FilePath $LogFile -Append
            } else {
                "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - DONE: $key" | Out-File -FilePath $LogFile -Append
            }
            
            $process.Dispose()
        }
    }
    
    foreach ($fileKey in $finishedFiles) {
        $activeJobs.Remove($fileKey)
    }
    
    # 2. Start new jobs if we have capacity
    if ($activeJobs.Count -lt $MaxConcurrentJobs) {
        # Scan for files
        $currentFiles = @(Get-ChildItem -Recurse -File)
        $startedNewJob = $false
        
        foreach ($file in $currentFiles) {
            if ($activeJobs.Count -ge $MaxConcurrentJobs) {
                break
            }
            
            # Skip if currently uploading
            if ($activeJobs.ContainsKey($file.FullName)) {
                continue
            }
            
            # Robust relative path calculation
            $relative = $file.FullName.Substring($basePath.Length)
            
            if ($MissingUpload) {
                $iaPath = $relative -replace '\\', '/'
                
                if ($uploadedFiles -contains $iaPath) {
                    continue
                }
            }
            
            Write-Host "Starting upload for $($file.Name) (Active: $($activeJobs.Count + 1) / $MaxConcurrentJobs)"
            
            # Build the command block to run in the new window
            $workerScript = @"
& ia.exe upload $ItemIdentifier "$($file.FullName)" --remote-name "$relative" --no-backup
`$exitCode = `$LASTEXITCODE
if (`$exitCode -eq 0) {
    Remove-Item -Path "$($file.FullName)" -Force -ErrorAction Ignore
}
exit `$exitCode
"@
            # Encode the script block to base64 to avoid quote escaping issues
            $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($workerScript))
            
            # Start the new process in a new minimized window
            try {
                $process = Start-Process powershell.exe -WindowStyle Minimized -ArgumentList "-NoProfile -EncodedCommand $encodedCommand" -PassThru -ErrorAction Stop
                $activeJobs[$file.FullName] = $process
                $startedNewJob = $true
            } catch {
                Write-Host "Failed to start process for $($file.FullName): $_" -ForegroundColor Red
            }
        }
        
        if (-not $startedNewJob) {
            # No files to process right now, wait a bit
            Start-Sleep -Seconds 5
        }
    } else {
        # At max capacity, wait for a job to finish
        Start-Sleep -Seconds 2
    }
}
